import cgi

print("Content-type: text/html\n")
print("<h1 align='center'>coming soon...</br>check back later</h1>")
