import socket
import sys

host = "localhost"
port = 9000

